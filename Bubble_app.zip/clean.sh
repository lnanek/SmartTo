 
rm -rf ./platforms/*
rm -rf ./plugins/*
rm -rf ./node_modules/*