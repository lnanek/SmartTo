 
keytool -genkey -v -keystore $1-release-key.keystore -alias alias_name -keyalg RSA -keysize 2048 -validity 10000