#include "nvram.h"
#include "bleprofile.h"

void AIR_NVRAM_Init()
{
}

unsigned int AIR_NVRAM_Write(unsigned int block, unsigned char *data, unsigned int length)
{
	if(length > 256 || block < 0x10 || block > 0x6f) //Specific to the NVRAM on the BCM20737
	{
		return 0;
	}
	
	return bleprofile_WriteNVRAM((UINT8)block, (UINT8)length, data);
}

unsigned int AIR_NVRAM_Read(unsigned int block, unsigned char *data, unsigned int length)
{
	if(length > 256 || block < 0x10 || block > 0x6f) //Specific to the NVRAM on the BCM20737
	{
		return 0;
	}
	
	return bleprofile_ReadNVRAM((UINT8)block, (UINT8)length, data);
}