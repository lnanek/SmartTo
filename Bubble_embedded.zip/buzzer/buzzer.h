// Copyright (c) 2014, Anaren Inc.
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer. 
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies, 
// either expressed or implied, of the FreeBSD Project.

#ifndef BUZZER_H
#define BUZZER_H

#ifndef bool
#define bool unsigned char
#endif

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#include "buzzer_config.h"
#include "types.h"

enum BUZZER_Note
{
	BUZZER_Note_Rest 	= 0,

	BUZZER_Note_C0 		= (UINT32)(16.351 * 1000.0),
	BUZZER_Note_CsDf0	= (UINT32)(17.324 * 1000.0),
	BUZZER_Note_D0 		= (UINT32)(18.354 * 1000.0),
	BUZZER_Note_DsEf0	= (UINT32)(19.445 * 1000.0),
	BUZZER_Note_E0 		= (UINT32)(20.601 * 1000.0),
	BUZZER_Note_F0 		= (UINT32)(21.827 * 1000.0),
	BUZZER_Note_FsGf0	= (UINT32)(23.124 * 1000.0),
	BUZZER_Note_G0 		= (UINT32)(24.499 * 1000.0),
	BUZZER_Note_GsAf0	= (UINT32)(25.956 * 1000.0),
	BUZZER_Note_A0		= (UINT32)(27.500 * 1000.0),
	BUZZER_Note_AsBf0	= (UINT32)(29.135 * 1000.0),
	BUZZER_Note_B0		= (UINT32)(30.868 * 1000.0),

	BUZZER_Note_C1 		= (UINT32)(32.703 * 1000.0),
	BUZZER_Note_CsDf1	= (UINT32)(34.648 * 1000.0),
	BUZZER_Note_D1 		= (UINT32)(36.708 * 1000.0),
	BUZZER_Note_DsEf1	= (UINT32)(38.891 * 1000.0),
	BUZZER_Note_E1 		= (UINT32)(41.203 * 1000.0),
	BUZZER_Note_F1 		= (UINT32)(43.654 * 1000.0),
	BUZZER_Note_FsGf1	= (UINT32)(46.249 * 1000.0),
	BUZZER_Note_G1 		= (UINT32)(48.999 * 1000.0),
	BUZZER_Note_GsAf1	= (UINT32)(51.913 * 1000.0),
	BUZZER_Note_A1		= (UINT32)(55.000 * 1000.0),
	BUZZER_Note_AsBf1	= (UINT32)(58.270 * 1000.0),
	BUZZER_Note_B1		= (UINT32)(61.735 * 1000.0),

	BUZZER_Note_C2 		= (UINT32)(65.406 * 1000.0),
	BUZZER_Note_CsDf2	= (UINT32)(69.296 * 1000.0),
	BUZZER_Note_D2 		= (UINT32)(73.416 * 1000.0),
	BUZZER_Note_DsEf2	= (UINT32)(77.782 * 1000.0),
	BUZZER_Note_E2 		= (UINT32)(82.407 * 1000.0),
	BUZZER_Note_F2 		= (UINT32)(87.307 * 1000.0),
	BUZZER_Note_FsGf2	= (UINT32)(92.499 * 1000.0),
	BUZZER_Note_G2 		= (UINT32)(97.999 * 1000.0),
	BUZZER_Note_GsAf2	= (UINT32)(103.826 * 1000.0),
	BUZZER_Note_A2		= (UINT32)(110.000 * 1000.0),
	BUZZER_Note_AsBf2	= (UINT32)(116.541 * 1000.0),
	BUZZER_Note_B2		= (UINT32)(123.471 * 1000.0),

	BUZZER_Note_C3 		= (UINT32)(130.813 * 1000.0),
	BUZZER_Note_CsDf3	= (UINT32)(138.591 * 1000.0),
	BUZZER_Note_D3 		= (UINT32)(146.832 * 1000.0),
	BUZZER_Note_DsEf3	= (UINT32)(155.563 * 1000.0),
	BUZZER_Note_E3 		= (UINT32)(164.814 * 1000.0),
	BUZZER_Note_F3 		= (UINT32)(174.614 * 1000.0),
	BUZZER_Note_FsGf3	= (UINT32)(184.997 * 1000.0),
	BUZZER_Note_G3 		= (UINT32)(195.998 * 1000.0),
	BUZZER_Note_GsAf3	= (UINT32)(207.652 * 1000.0),
	BUZZER_Note_A3		= (UINT32)(220.000 * 1000.0),
	BUZZER_Note_AsBf3	= (UINT32)(233.082 * 1000.0),
	BUZZER_Note_B3		= (UINT32)(246.942 * 1000.0),

	BUZZER_Note_C4 		= (UINT32)(261.626 * 1000.0),
	BUZZER_Note_CsDf4	= (UINT32)(277.183 * 1000.0),
	BUZZER_Note_D4 		= (UINT32)(293.665 * 1000.0),
	BUZZER_Note_DsEf4	= (UINT32)(311.127 * 1000.0),
	BUZZER_Note_E4 		= (UINT32)(339.628 * 1000.0),
	BUZZER_Note_F4 		= (UINT32)(349.228 * 1000.0),
	BUZZER_Note_FsGf4	= (UINT32)(369.994 * 1000.0),
	BUZZER_Note_G4 		= (UINT32)(391.995 * 1000.0),
	BUZZER_Note_GsAf4	= (UINT32)(415.305 * 1000.0),
	BUZZER_Note_A4		= (UINT32)(440.000 * 1000.0),
	BUZZER_Note_AsBf4	= (UINT32)(466.164 * 1000.0),
	BUZZER_Note_B4		= (UINT32)(493.883 * 1000.0),

	BUZZER_Note_C5 		= (UINT32)(523.251 * 1000.0),
	BUZZER_Note_CsDf	= (UINT32)(554.365 * 1000.0),
	BUZZER_Note_D5 		= (UINT32)(587.330 * 1000.0),
	BUZZER_Note_DsEf	= (UINT32)(622.254 * 1000.0),
	BUZZER_Note_E5 		= (UINT32)(659.255 * 1000.0),
	BUZZER_Note_F5 		= (UINT32)(698.456 * 1000.0),
	BUZZER_Note_FsGf	= (UINT32)(739.989 * 1000.0),
	BUZZER_Note_G5 		= (UINT32)(783.991 * 1000.0),
	BUZZER_Note_GsAf	= (UINT32)(830.609 * 1000.0),
	BUZZER_Note_A5		= (UINT32)(880.000 * 1000.0),
	BUZZER_Note_AsBf	= (UINT32)(932.328 * 1000.0),
	BUZZER_Note_B5		= (UINT32)(987.767 * 1000.0),

	BUZZER_Note_C6 		= (UINT32)(1046.502 * 1000.0),
	BUZZER_Note_CsDf6	= (UINT32)(1108.731 * 1000.0),
	BUZZER_Note_D6 		= (UINT32)(1174.659 * 1000.0),
	BUZZER_Note_DsEf6	= (UINT32)(1244.508 * 1000.0),
	BUZZER_Note_E6 		= (UINT32)(1318.510 * 1000.0),
	BUZZER_Note_F6 		= (UINT32)(1396.913 * 1000.0),
	BUZZER_Note_FsGf6	= (UINT32)(1479.978 * 1000.0),
	BUZZER_Note_G6 		= (UINT32)(1567.982 * 1000.0),
	BUZZER_Note_GsAf6	= (UINT32)(1661.219 * 1000.0),
	BUZZER_Note_A6		= (UINT32)(1760.000 * 1000.0),
	BUZZER_Note_AsBf6	= (UINT32)(1864.655 * 1000.0),
	BUZZER_Note_B6		= (UINT32)(1975.533 * 1000.0),

	BUZZER_Note_C7 		= (UINT32)(2093.005 * 1000.0),
	BUZZER_Note_CsDf7	= (UINT32)(2217.461 * 1000.0),
	BUZZER_Note_D7 		= (UINT32)(2349.318 * 1000.0),
	BUZZER_Note_DsEf7	= (UINT32)(2489.016 * 1000.0),
	BUZZER_Note_E7 		= (UINT32)(2637.021 * 1000.0),
	BUZZER_Note_F7 		= (UINT32)(2793.826 * 1000.0),
	BUZZER_Note_FsGf7	= (UINT32)(2959.955 * 1000.0),
	BUZZER_Note_G7 		= (UINT32)(3135.964 * 1000.0),
	BUZZER_Note_GsAf7	= (UINT32)(3322.438 * 1000.0),
	BUZZER_Note_A7		= (UINT32)(3520.000 * 1000.0),
	BUZZER_Note_AsBf7	= (UINT32)(3729.310 * 1000.0),
	BUZZER_Note_B7		= (UINT32)(3951.066 * 1000.0),

	BUZZER_Note_C8 		= (UINT32)(4186.009 * 1000.0),
	BUZZER_Note_CsDf8	= (UINT32)(4434.922 * 1000.0),
	BUZZER_Note_D8 		= (UINT32)(4698.636 * 1000.0),
	BUZZER_Note_DsEf8	= (UINT32)(4978.032 * 1000.0),
	BUZZER_Note_E8 		= (UINT32)(5274.042 * 1000.0),
	BUZZER_Note_F8 		= (UINT32)(5587.652 * 1000.0),
	BUZZER_Note_FsGf8	= (UINT32)(5919.910 * 1000.0),
	BUZZER_Note_G8 		= (UINT32)(6271.928 * 1000.0),
	BUZZER_Note_GsAf8	= (UINT32)(6644.876 * 1000.0),
	BUZZER_Note_A8		= (UINT32)(7040.000 * 1000.0),
	BUZZER_Note_AsBf8	= (UINT32)(7458.620 * 1000.0),
	BUZZER_Note_B8		= (UINT32)(7902.132 * 1000.0),

	BUZZER_Note_C9 		= (UINT32)(8372.018 * 1000.0),
	BUZZER_Note_CsDf9	= (UINT32)(8869.844 * 1000.0),
	BUZZER_Note_D9 		= (UINT32)(9399.272 * 1000.0),
	BUZZER_Note_DsEf9	= (UINT32)(9956.064 * 1000.0),
	BUZZER_Note_E9 		= (UINT32)(10548.084 * 1000.0),
	BUZZER_Note_F9 		= (UINT32)(11175.304 * 1000.0),
	BUZZER_Note_FsGf9	= (UINT32)(11839.820 * 1000.0),
	BUZZER_Note_G9 		= (UINT32)(12543.856 * 1000.0),
	BUZZER_Note_GsAf9	= (UINT32)(13289.752 * 1000.0),
	BUZZER_Note_A9		= (UINT32)(14080.000 * 1000.0),
	BUZZER_Note_AsBf9	= (UINT32)(14917.240 * 1000.0),
	BUZZER_Note_B9		= (UINT32)(15804.264 * 1000.0)
};

/**
 * BUZZER_Init will initialize the required setting for the buzzer driver.
 * This function must be called before any other BUZZER function is executed.
*/
void BUZZER_Init();

/**
 * BUZZER_Start will have the buzzer play a note
@param note The note in Hz per cycle that the buzzer should play, see predefined notes for examples
*/
void BUZZER_Start(uint32 note);

/**
 * BUZZER_Stop will stop the buzzer from playing it's current note.
*/
void BUZZER_Stop();;

#endif