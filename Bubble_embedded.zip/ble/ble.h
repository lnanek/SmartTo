// Copyright (c) 2014, Anaren Inc.
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer. 
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies, 
// either expressed or implied, of the FreeBSD Project.

#ifndef AIR_BLE_H
#define AIR_BLE_H

#ifndef bool
#define bool unsigned char
#endif

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

typedef enum {
	AIR_BLE_DISCOVERABLE_NONE = 0,
	AIR_BLE_DISCOVERABLE_UNDIRECTED,
	AIR_BLE_DISCOVERABLE_DIRECTED,
} AIR_BLE_DiscoveryMode;

typedef enum {
	AIR_BLE_PAIRING_NONE = 0,
	AIR_BLE_PAIRING_OPEN,
	AIR_BLE_PAIRING_OOB,
	AIR_BLE_PAIRING_PASSKEY,
} AIR_BLE_PairingMode;

void AIR_BLE_Init();

void AIR_BLE_SetDiscoverable(bool discoverable);

void AIR_BLE_SetDirectedDiscoverable(bool discoverable, unsigned char *address);

AIR_BLE_DiscoveryMode AIR_BLE_GetDiscoverable();

void AIR_BLE_SetPairingMode(AIR_BLE_PairingMode mode);

void AIR_BLE_SetPassKey(unsigned char *key, unsigned int length);

void AIR_BLE_SetOOBTk(unsigned char *tk, unsigned int length);

void AIR_BLE_GetMacAddress(unsigned char *addressBuf, unsigned int length);

#endif /* AIR_BLE_H */
