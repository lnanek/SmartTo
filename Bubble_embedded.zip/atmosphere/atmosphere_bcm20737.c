#include "bleprofile.h"
#include "../air_gatt_defines.h"

void *__wrap_memset(void *v_src, int c, size_t n)
{
	return (void *)__aeabi_memset(v_src,n,c);
}

void *__wrap_memcpy(void *v_dst, const void *v_src, size_t c)
{
	return (void *)__aeabi_memcpy(v_dst,v_src,c);
}

void ATMOSPHERE_NotifyFunction(unsigned int functionId, char *data)
{
	char buffer[128];
	int i = 0;
	
	buffer[0] = 0x05;
	buffer[1] = functionId;
	
	for(i = 0; i + 2 < 126; i++)
	{
		buffer[i + 2] = data[i];
		
		if(data[i] == '\0')
		{
			break;
		}
	}
	
	bleprofile_sendNotification(ATMOSPHERE_NOTIFY_HANDLE, (UINT8 *)buffer, i + 3);
}