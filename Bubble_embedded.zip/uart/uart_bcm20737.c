#include "uart.h"
#include "../circularBuffer/circularBuffer.h"
#include "string.h"
#include "stdio.h"
#include "bleprofile.h"
#include "spar_utils.h"
#include "puart.h"

static void puart_rx_callback(void* unused);
static void puart_tx_callback(void* unused);

unsigned char uartRXCircularBufferMemory[AIR_UART_RX_CIRCULAR_BUFFER_SIZE];
unsigned char uartTXCircularBufferMemory[AIR_UART_TX_CIRCULAR_BUFFER_SIZE];
struct sCircularBuffer uartRXCircularBuffer;
struct sCircularBuffer uartTXCircularBuffer;

static air_uart_callback_func_ptr uartRXCallback = NULL;
static air_uart_callback_func_ptr uartTXCallback = NULL;

void AIR_UART_Init()
{
	CircularBuffer_Init(&uartRXCircularBuffer, uartRXCircularBufferMemory, AIR_UART_RX_CIRCULAR_BUFFER_SIZE);

	CircularBuffer_Init(&uartTXCircularBuffer, uartTXCircularBufferMemory, AIR_UART_TX_CIRCULAR_BUFFER_SIZE);
	
	extern puart_UartConfig puart_config;
	
#ifdef AIR_UART_BAUD_460800
	puart_config.baudrate = 460800;
	
#elif defined AIR_UART_BAUD_230400
	puart_config.baudrate = 230400;
	
#elif defined AIR_UART_BAUD_115200
	puart_config.baudrate = 115200;
	
#elif defined AIR_UART_BAUD_57600
	puart_config.baudrate = 57600;
	
#elif defined AIR_UART_BAUD_38400
	puart_config.baudrate = 38400;
	
#elif defined AIR_UART_BAUD_19200
	puart_config.baudrate = 19200;
	
#elif defined AIR_UART_BAUD_9600
	puart_config.baudrate = 9600;
	
#else
	puart_config.baudrate = 9600;
#endif
	
	// Select the uart pins for RXD, TXD and optionally CTS and RTS.
	// If hardware flow control is not required like here, set these
	// pins to 0x00. See Table 1 and Table 2 for valid options.
	puart_selectUartPads(AIR_UART_RX_PIN, AIR_UART_TX_PIN, 0x00, 0x00);

	// Initialize the peripheral uart driver
	puart_init();

// 	puart_setBaudrate(0, 0, puart_cfg.baudrate);
	puart_flowOff();
	puart_enableTx();

	P_UART_INT_CLEAR(P_UART_ISR_RX_AFF_MASK);
	P_UART_INT_CLEAR(P_UART_ISR_TX_FAE_MASK);

	/* set watermark to 1 byte - will interrupt on every byte received. */
	P_UART_WATER_MARK_RX_LEVEL (1);
	P_UART_WATER_MARK_TX_LEVEL (1);

	// Almost Full interrupt
	P_UART_INT_ENABLE |= P_UART_ISR_RX_AFF_MASK;
	P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
	
	// Set callback function to app callback function.
	puart_rxCb = puart_rx_callback;
	puart_txCb = puart_tx_callback;
	
	// Enable the CPU level interrupt
	puart_enableInterrupt();
}

void AIR_UART_SetBaudRate(unsigned int baudrate)
{
	puart_setBaudrate(0, 0, baudrate);
}

void AIR_UART_FlushTX()
{
	while((uartTXCircularBuffer.write == uartTXCircularBuffer.read) ? false : true)
	{
		//This is to make sure that we don't have any optimization ruining this inifinite nop loop
		asm("");
	}
}

void AIR_UART_FlushRX()
{
	while(puart_rxFifoNotEmpty())
	{
		//This is to make sure that we don't have any optimization ruining this inifinite nop loop
		asm("");
	}
}

unsigned char AIR_UART_Write(unsigned char* pBuffer, unsigned int count)
{
	unsigned char i;
	char temp;
	
	for(i = 0; i < count; i++)
	{
		if(CircularBuffer_Write(&uartTXCircularBuffer, pBuffer[i]))
		{
			if(!CircularBuffer_Read(&uartTXCircularBuffer, &temp))
			{
				puart_write(temp);
				P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
			}
			return i;
		}
	}
	
	if(!CircularBuffer_Read(&uartTXCircularBuffer, &temp))
	{
		puart_write(temp);
		P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
	}
	return i;
}

unsigned char AIR_UART_StrnPrint(unsigned char* pBuffer, unsigned int count)
{
	unsigned char i;
	char temp;
	
	for(i = 0; i < count; i++)
	{
		if((pBuffer[i] == '\0') || CircularBuffer_Write(&uartTXCircularBuffer, pBuffer[i]))
		{
			if(!CircularBuffer_Read(&uartTXCircularBuffer, &temp))
			{
				puart_write(temp);
				P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
			}
			return i;
		}
	}
	
	if(!CircularBuffer_Read(&uartTXCircularBuffer, &temp))
	{
		puart_write(temp);
		P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
	}
	return i;
}


unsigned char AIR_UART_Print(unsigned char *pBuffer)
{
	unsigned char i;
	char temp;
	
	for(i = 0; i < AIR_UART_RX_CIRCULAR_BUFFER_SIZE; i++)
	{
		if((pBuffer[i] == '\0') || CircularBuffer_Write(&uartTXCircularBuffer, pBuffer[i]))
		{
			if(!CircularBuffer_Read(&uartTXCircularBuffer, &temp))
			{
				puart_write(temp);
				P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
			}
			return i;
		}
	}
	
	if(!CircularBuffer_Read(&uartTXCircularBuffer, &temp))
	{
		puart_write(temp);
		P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
	}
	return i;
}

unsigned char AIR_UART_Read(unsigned char* pBuffer, unsigned int count)
{
	unsigned char i;
	
	for(i = 0; i < count; i++)
	{
		if(CircularBuffer_Read(&uartRXCircularBuffer, &pBuffer[i]))
		{
			return i;
		}
	}
	
	return i;
}

unsigned char AIR_UART_StrnRead(unsigned char* pBuffer, unsigned int count)
{
	unsigned char i;
	
	for(i = 0; i < count - 1; i++)
	{
		if(CircularBuffer_Read(&uartRXCircularBuffer, &pBuffer[i]))
		{
			pBuffer[i + 1] = '\0';
			return i;
		}
	}
	
	pBuffer[i + 1] = '\0';
	return i;
}

/*
 * 
 */
void AIR_UART_RegisterRXCallback(air_uart_callback_func_ptr func)
{
	uartRXCallback = func;
}

/*
 * 
 */
void AIR_UART_RegisterTXCallback(air_uart_callback_func_ptr func)
{
	uartTXCallback = func;
}

static void puart_rx_callback(void* unused)
{
	// There can be at most 16 bytes in the HW FIFO.
	char  readbyte;
	
	// empty the FIFO
	while(puart_rxFifoNotEmpty() && puart_read(&readbyte))
	{
		//We recieved a byte place it into the circle buffer.
		CircularBuffer_Write(&uartRXCircularBuffer, readbyte);
		
		if(uartRXCallback != NULL)
		{
			uartRXCallback(readbyte);
		}
	}
	
	P_UART_INT_CLEAR(P_UART_ISR_RX_AFF_MASK);
	// enable UART interrupt in the Main Interrupt Controller and RX Almost Full in the UART Interrupt Controller
	P_UART_INT_ENABLE |= P_UART_ISR_RX_AFF_MASK;
}

static void puart_tx_callback(void* unused)
{
	char temp;
	
	P_UART_INT_CLEAR(P_UART_ISR_TX_FAE_MASK);
	
	if(!CircularBuffer_Read(&uartTXCircularBuffer, &temp))
	{
		puart_write(temp);
		P_UART_INT_ENABLE |= P_UART_ISR_TX_FAE_MASK;
		
		if(uartTXCallback != NULL)
		{
			uartTXCallback(temp);
		}
	}
}
