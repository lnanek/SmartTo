// Copyright (c) 2014, Anaren Inc.
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer. 
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies, 
// either expressed or implied, of the FreeBSD Project.

#ifndef AIR_UART_H
#define AIR_UART_H

#ifndef bool
#define bool unsigned char
#endif

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#include "uart_config.h"

typedef void (*air_uart_callback_func_ptr)(char);

/**
 * AIR_UART_Init will iniatilize all required UART subsystems of the board.
 * It will also initialize all required software and hardware buffers for the user.
 * This function must be executed before any other UART function is used.
*/
void AIR_UART_Init();

/**
*/
void AIR_UART_SetBaudRate(unsigned int baudrate);

/**
 * AIR_UART_Write inserts into the circular TX buffer a number of bytes from the buffer pointed
 * to by the buffer. Then the UART driver is told to start shifting those bytes
 * out the serial port.
@param buffer array of bytes that will be inserted into the output buffer
@param count number of bytes inserted into the tx buffer from the buffer variable
@return the number of bytes that were placed into the TX buffer from the buffer pointed to by buffer.
*/
unsigned char AIR_UART_Write(unsigned char*, unsigned int);

/**
@param buffer
@param count
*/
// unsigned char AIR_UART_StrnPrint(unsigned char*, unsigned int);

/**
 * AIR_UART_Print will insert into the TX buffer the array of bytes pointed to by the buffer argument.
 * It will stop inserting bytes into the TX buffer once a null '\0' character is read in from the buffer argument.
 * If the buffer does not contain any null characters this function will overflow passed the buffer's memory bounds.
@param buffer
@return the number of bytes that were placed into the TX buffer from the buffer pointed to by buffer.
*/
unsigned char AIR_UART_Print(unsigned char *);

/**
 * AIR_UART_Read will insert the contents of the RX buffer into the array pointed to by buffer upto the size of the buffer provided by the count varible.
 * If the number of bytes currently in the RX buffer exceeds the size of the buffer provided then those bytes will remain in the RX buffer until another read function is performed.
@param buffer a pointer to an array.
@param count the number of bytes that are able to be placed into the array pointed to by buffer.
@return the number of bytes read in from the RX buffer into the buffer pointed to by buffer.
*/
unsigned char AIR_UART_Read(unsigned char*, unsigned int);

/**
@param buffer
@param count
*/
// unsigned char AIR_UART_StrnRead(unsigned char*, unsigned int);

/**
 * AIR_UART_FlushTX will make sure that the hardware buffer of the microcontroller has compleletly shifted all of it's contents out the UART line.
*/
void AIR_UART_FlushTX();

/**
 * AIR_UART_FlushRX will make sure that all the contents of the recieve hardware buffer have been shifted inot the software buffer making them available for reading with AIR_UART_Read
*/
void AIR_UART_FlushRX();

/*
 * 
 */
void AIR_UART_RegisterRXCallback(air_uart_callback_func_ptr func);

/*
 * 
 */
void AIR_UART_RegisterTXCallback(air_uart_callback_func_ptr func);

#endif
