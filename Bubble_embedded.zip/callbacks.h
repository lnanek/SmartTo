
//Dynamically genreated header, do not edit the following.
#ifndef CALLBACKS_H
#define CALLBACKS_H

#include "bleprofile.h"
#include "bleapp.h"
#include "atmosphere/atmosphere.h"
#include "string.h"
#include "stdio.h"
#include "platform.h"
#include "spar_utils.h"
#include "power/power.h"
#include "gatt/gatt.h"
#include "json/json.h"
#include "gpio/gpio.h"
#include "uart/uart.h"
#include "i2c/i2c.h"
#include "buzzer/buzzer.h"
#include "ble/ble.h"

void setup();

void interval();

void connected();

void disconnected();

#define ID_Function4 0x13
char *Function4(char *data, int length);
#define ID_PPWMSet23 0x15
char *PPWMSet23(char *data, int length);
#define ID_PWMSet21 0x17
char *PWMSet21(char *data, int length);
#define ID_PWMSet22 0x19
char *PWMSet22(char *data, int length);
#endif
