#include "fp_math.h"

#define uint64 UINT64
#define int64 INT64

struct ieee754_binary32
{
  uint8 sign;
  int8 exp;
  uint32 value;
};

struct ieee754_binary64
{
  uint8 sign;
  int8 exp;
  uint64 value;
};

struct ieee754_binary32 Float2Struct(float val)
{
  struct ieee754_binary32 returnValue;
  union tmpVar
  {
    float floatVal;
    uint32 intVal;
  }tmpValue;

  tmpValue.floatVal = val;

  returnValue.sign = (uint8)((tmpValue.intVal >> 31) & 0x01);
  returnValue.exp = (int8)((tmpValue.intVal >> 23) & 0xFF);
  returnValue.value = tmpValue.intVal & 0x007FFFFF;

  if (returnValue.exp != 0) returnValue.value |= 0x00800000;
  if (returnValue.value != 0) returnValue.exp -= 127;

  return returnValue;
}

struct ieee754_binary64 Double2Struct(double val)
{
  struct ieee754_binary64 returnValue;
  union tmpVar
  {
    double doubleVal;
    uint64 intVal;
  }tmpValue;

  tmpValue.doubleVal = val;

  returnValue.sign = (uint8)((tmpValue.intVal >> 63) & 0x01);
  returnValue.exp = (int16)((tmpValue.intVal >> 52) & 0x7FF);
  returnValue.value = tmpValue.intVal & 0x000FFFFFFFFFFFFF;

  if (returnValue.exp != 0) returnValue.value |= 0x0010000000000000;
  returnValue.exp -= 1023;

  return returnValue;
}

float Struct2Float(struct ieee754_binary32 *val)
{
  union tmpVar
  {
    float floatVal;
    uint32 intVal;
  }tmpValue;
  int8 tmpExp = val->exp + 127;

  tmpValue.intVal = val->value;

  if(tmpValue.intVal == 0)
  {
    tmpExp = 0;
  }
  else
  {
    while (tmpValue.intVal >= 0x01000000)
    {
      tmpValue.intVal >>= 1;
      tmpExp += 1;
    }

    while (tmpValue.intVal < 0x00800000)
    {
      tmpValue.intVal <<= 1;
      tmpExp -= 1;
    }
  }

  tmpValue.intVal &= 0x007FFFFF;
  tmpValue.intVal |= ((int32)tmpExp & 0xFF) << 23;
  tmpValue.intVal |= ((uint32)val->sign & 0x01) << 31;

  return tmpValue.floatVal;
}

double Struct2Double(struct ieee754_binary64 *val)
{
  union tmpVar
  {
    double doubleVal;
    uint64 intVal;
  }tmpValue;
  int16 tmpExp = val->exp + 1023;

  tmpValue.intVal = val->value;

  while (tmpValue.intVal >= 0x0020000000000000)
  {
    tmpValue.intVal >>= 1;
    tmpExp += 1;
  }

  tmpValue.intVal &= 0x000FFFFFFFFFFFFF;
  tmpValue.intVal |= ((int64)tmpExp & 0x7FF) << 52;
  tmpValue.intVal |= ((uint64)val->sign & 0x01) << 63;

  return tmpValue.doubleVal;
}

float fp_add(float a, float b)
{
  struct ieee754_binary32 a_struct = Float2Struct(a);
  struct ieee754_binary32 b_struct = Float2Struct(b);
  struct ieee754_binary32 result;

  if (a_struct.exp > b_struct.exp)
  {
    b_struct.value >>= (a_struct.exp - b_struct.exp);
    result.exp = a_struct.exp;
  }
  else if (b_struct.exp > a_struct.exp)
  {
    a_struct.value >>= (b_struct.exp - a_struct.exp);
    result.exp = b_struct.exp;
  }
  else
  {
    result.exp = a_struct.exp;
  }

  if (a_struct.sign)
  {
    a_struct.value ^= 0xFFFFFFFF;
    a_struct.value += 1;
  }

  if (b_struct.sign)
  {
    b_struct.value ^= 0xFFFFFFFF;
    b_struct.value += 1;
  }

  result.value = a_struct.value + b_struct.value;
  result.sign = (result.value >> 31) & 0x01;
  if (result.sign)
  {
    result.value -= 1;
    result.value ^= 0xFFFFFFFF;
  }

  return Struct2Float(&result);
}

float fp_sub(float a, float b)
{
  return fp_add(a, fp_mult(b, -1.0));
}

float fp_mult(float a, float b)
{
  struct ieee754_binary32 a_struct = Float2Struct(a);
  struct ieee754_binary32 b_struct = Float2Struct(b);
  struct ieee754_binary32 result;
  uint64 tmpValue;

  result.sign = a_struct.sign ^ b_struct.sign;
  result.exp = a_struct.exp + b_struct.exp;

  tmpValue = (uint64)a_struct.value * (uint64)b_struct.value;
  result.value = (uint32)(tmpValue >> 23);

  return Struct2Float(&result);
}

float fp_div(float a, float b)
{
  struct ieee754_binary32 a_struct = Float2Struct(a);
  struct ieee754_binary32 b_struct = Float2Struct(b);
  struct ieee754_binary32 result;
  uint8 i,j;

  if (fp_cmp(b, 0.0) == 0)
  {
    union tmpVar
    {
      float floatVal;
      uint32 intVal;
    }tmpValue;

    tmpValue.intVal = 0x7F800000;

    return tmpValue.floatVal;
  }

  result.sign = a_struct.sign ^ b_struct.sign;
  result.exp = a_struct.exp - b_struct.exp - 1;

  a_struct.value <<= 8;
  for (i=0; i<16; i++)
  {
    if (a_struct.value & 0x80000000) break;
    a_struct.value <<= 1;
  }

  for (j=i; j<16; j++)
  {
    if (!(b_struct.value & 0xFFFF0000)) break;
    b_struct.value >>= 1;
  }
  result.value = (a_struct.value / b_struct.value) << (16 - j);

  return Struct2Float(&result);
}

float fp_pow(float a, uint16 n)
{
  uint16 i;
  float result = a;

  switch (n)
  {
    case 0 :
      result = 1.0;
      break;
    case 1 :
      result = a;
      break;
    default :
      for (i=1; i<n; i++)
      {
        result = fp_mult(result, a);
      }
      break;
  }

  return result;
}

int8 fp_cmp(float a, float b)
{
  struct ieee754_binary32 a_struct = Float2Struct(a);
  struct ieee754_binary32 b_struct = Float2Struct(b);

  // a is pos, b is neg
  if (!a_struct.sign && b_struct.sign) return 1;

  // a is neg, b is pos
  if (a_struct.sign && !b_struct.sign) return -1;

  // a is pos, b is pos
  if (!a_struct.sign && !b_struct.sign)
  {
    if ((a_struct.value == 0) && (b_struct.value != 0)) return -1;
    if ((b_struct.value == 0) && (a_struct.value != 0)) return 1;

    if (a_struct.exp > b_struct.exp) return 1;
    if (a_struct.exp < b_struct.exp) return -1;

    if (a_struct.value > b_struct.value) return 1;
    if (a_struct.value < b_struct.value) return -1;
    return 0;
  }

  // a is neg, b is neg
  if ((a_struct.value == 0) && (b_struct.value != 0)) return 1;
  if ((b_struct.value == 0) && (a_struct.value != 0)) return -1;

  if (a_struct.exp < b_struct.exp) return 1;
  if (a_struct.exp > b_struct.exp) return -1;

  if (a_struct.value < b_struct.value) return 1;
  if (a_struct.value > b_struct.value) return -1;
  return 0;
}

float fp_sqrt(float a)
{
  struct ieee754_binary32 a_struct = Float2Struct(a);
  float val;
  float low = 0.0;
  float high;
  float mid;
  float oldmid = -1.0;
  float tmpVar = a;
  uint8 expOffset = 0;
  uint8 i;

  if (fp_cmp(a, 0.0) == -1)
  {
    union tmpUnion
    {
      float floatVal;
      uint32 intVal;
    }tmpValue;

    tmpValue.intVal = 0x7FFFFFFF;

    return tmpValue.floatVal;
  }

  if (fp_cmp(a, 0.0) == 0) return 0.0;

  while (fp_cmp(tmpVar, 1.0) == -1)
  {
    tmpVar = fp_mult(tmpVar, 100.0);
    expOffset++;
  }

  val = tmpVar;
  high = tmpVar;
  mid = tmpVar;

  while ((fp_cmp(fp_sub(oldmid, mid), 0.00001) != -1) || (fp_cmp(fp_sub(mid, oldmid), 0.00001) != -1))
  {
    oldmid = mid;
    mid = fp_div(fp_add(high, low), 2.0);

    if (fp_cmp(fp_pow(mid, 2), val) == 1)
    {
      high = mid;
    }
    else
    {
      low = mid;
    }
  }

  if (fp_cmp(a, 1.0) == -1)
  {
    for (i=0; i<expOffset; i++)
    {
      mid = fp_div(mid, 10.0);
    }
  }

  return mid;
}


// Broadcom specific functions.  These allow using standard math operators such as + - * / in the source code.
float __aeabi_fmul(float a, float b)
{
  return fp_mult(a, b);
}

float __aeabi_fdiv(float a, float b)
{
  return fp_div(a, b);
}

float pow(float a, uint16 n)
{
  return fp_pow(a, n);
}

float sqrt(float a)
{
  return fp_sqrt(a);
}

float __aeabi_fadd(float a, float b)
{
  return fp_add(a, b);
}

float __aeabi_fsub(float a, float b)
{
  return fp_sub(a,b);
}

double __aeabi_f2d(float a)
{
  struct ieee754_binary32 a_struct = Float2Struct(a);
  struct ieee754_binary64 result;

  result.sign = a_struct.sign;
  result.exp = a_struct.exp;
  result.value = (uint64)a_struct.value << 29;

  return Struct2Double(&result);
}

float __aeabi_d2f(double a)
{
  struct ieee754_binary64 a_struct = Double2Struct(a);
  struct ieee754_binary32 result;

  result.sign = a_struct.sign;
  result.exp = a_struct.exp;
  result.value = (a_struct.value >> 29) & 0x007FFFFF;

  return Struct2Float(&result);
}

float __aeabi_i2f(int16 a)
{
  struct ieee754_binary32 result;
  uint64 tempVar64;
  uint16 tempVar16 = (uint16)a;

  result.sign = (tempVar16 >> 15) & 0x01;
  result.exp = 0;

  result.value = (result.sign) ? (tempVar16 - 1) ^ 0xFFFF : tempVar16;
  tempVar64 = (uint64)result.value << 23;
  while(tempVar64 >= 0x01000000)
  {
	  tempVar64 >>= 1;
    result.exp += 1;
  }
  result.value = tempVar64;

  return Struct2Float(&result);
}

int16 __aeabi_f2iz(float a)
{
  struct ieee754_binary32 a_struct = Float2Struct(a);
  int64 tempVar = (int64)a_struct.value;
  int32 result;

  if (a_struct.exp < 0) return 0;

  if(a_struct.exp > 0)
  {
    tempVar <<= a_struct.exp;
    a_struct.exp -= a_struct.exp;
  }

  result = tempVar >> 23;

  if (result > 0x7FFF)
  {
    result = a_struct.sign ? 0x8000 : 0x7FFF;
  }

  if (a_struct.sign)
  {
    result ^= 0xFFFF;
    result += 1;
  }

  return (int16)result;
}

int8 __aeabi_fcmpeq(float a, float b)
{
  return (fp_cmp(a, b) == 0) ? 1: 0;
}