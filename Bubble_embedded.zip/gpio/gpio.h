// Copyright (c) 2014, Anaren Inc.
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer. 
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies, 
// either expressed or implied, of the FreeBSD Project.

#ifndef AIR_GPIO_H
#define AIR_GPIO_H

#ifndef bool
#define bool unsigned char
#endif

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#include "gpio_config.h"

enum
{
	AIR_GPIO_INPUT_PULL_UP = 1,             /* Input with an internal pull-up resistor - use with devices that actively drive the signal low - e.g. button connected to ground */
	AIR_GPIO_INPUT_PULL_DOWN,           /* Input with an internal pull-down resistor - use with devices that actively drive the signal high - e.g. button connected to a power rail */
	AIR_GPIO_INPUT_HIGH_IMPEDANCE,      /* Input - must always be driven, either actively or by an external pullup resistor */
	AIR_GPIO_OUTPUT_PUSH_PULL,          /* Output actively driven high and actively driven low - must not be connected to other active outputs - e.g. LED output */
	AIR_GPIO_OUTPUT_OPEN_DRAIN_NO_PULL, /* Output actively driven low but is high-impedance when set high - can be connected to other open-drain/open-collector outputs. Needs an external pull-up resistor */
	AIR_GPIO_OUTPUT_OPEN_DRAIN_PULL_UP, /* Output actively driven low and is pulled high with an internal resistor when set high - can be connected to other open-drain/open-collector outputs. */
	AIR_GPIO_TRIGGER_RISING_EDGE,
	AIR_GPIO_TRIGGER_FALLING_EDGE,
	AIR_GPIO_TRIGGER_BOTH_EDGES
};

typedef void (*air_gpio_callback_func_ptr)(void);

/**
 * GPIO_Init will configure all required hardware systems for the use of GPIO
 * This function must be called before any GPIO functions are executed.
 */
void AIR_GPIO_Init();

/**
 * AIR_GPIO_SetMode will change the current behaviour of a selected pin.
 * Available mode types are defined are defined within this driver
@param pin The pin to configure with the mode flags.
@param mode The configuration mode flags.
 */
void AIR_GPIO_SetMode(unsigned int pin, int mode);

/**
 * AIR_GPIO_GetMode will return the current state of the pin
 * Available mode types are defined are defined within this driver
@param pin The pin to configure with the mode flags.
*/
int AIR_GPIO_GetMode(unsigned int pin);

/**
 * AIR_GPIO_Read will read the current state of a pin.
 * The pin should be configured in an appropriate input mode before attempting to use this function.
@param pin The pin thats state should be read
@return The current state of the pin.
 */
bool AIR_GPIO_Read(unsigned int pin);

/**
 * AIR_GPIO_Write will change the current state of the pin
 * The pin should be configured in a n appropriate output mode before attempting to use this function.
@param pin The pin thats output state should be changed.
@param value The state that the pin should be changed to.
 */
void AIR_GPIO_Write(unsigned int pin, bool value);

/**
 * AIR_GPIO_RegisterInterrupt will register a callback function with the GPIO inturrupt handler and configure the inturrupt flags for the GPIO pin
 * This function will set the current mode of the pin to an appropriate mode for registering an inturrupt.
@param pin The pin that should be register as an inturrupt
@param func The callback function pointer that should be executed in the event an inturrupt on that pin
@param flags The inturrupt flags that are to be configured for that pin.
 */
void AIR_GPIO_RegisterInterrupt(unsigned int pin, air_gpio_callback_func_ptr func, int flags);

/**
 * AIR_PWM_Enable will enable a pin to be used as a PWM output setting it to default values.
 * Not all pins are PWM capable. Please refer to the hardware manual for the particular board to determine which pins are available for PWM
@param pin The pin that should be enabled for PWM
 */
void AIR_PWM_Enable(unsigned int pin);

/**
 * AIR_PWM_Configure will enable a pin for PWM and allow you to set the initial values for the PWM systems
 * 
@param pin
@param toggleCount
@param initCount
 */
void AIR_PWM_Configure(unsigned int pin, unsigned int toggleCount, unsigned int initCount);

/**
 * 
@param pin
 */
void AIR_PWM_Disable(unsigned int pin);

/**
 * 
@param pin
@param toggleCount
@param initCount
 */
void AIR_PWM_SetAdv(unsigned int pin, int toggleCount, int initCount);

/**
 * 
@param pin
@param toggleCount
 */
void AIR_PWM_Set(unsigned int pin, int toggleCount);

/**
 * 
@param pin
@param toggleCount
 */
void AIR_PWM_Change(unsigned int pin, int toggleCount);

/**
 * 
@param pin
 */
void AIR_ADC_Enable(unsigned int pin);

/**
 * 
@param pin
@param millivolts
 */
void AIR_ADC_SetReferenceVoltage(unsigned int pin, unsigned int millivolts);

/**
 * 
@param pin
 */
unsigned int AIR_ADC_Read(unsigned int pin);

/**
 * 
@param pin
 */
int AIR_ADC_ReadRaw(unsigned int pin);

#endif