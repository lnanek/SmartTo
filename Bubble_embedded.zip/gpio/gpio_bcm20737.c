#include "gpio.h"
#include "platform.h"
#include "devicelpm.h"
#include "hidddriversconfig.h"
#include "gpiodriver.h"

// To use PWM, we will need the auxiliary clock and the PWM drier.
#include "aclk.h"
#include "pwm.h"
#include "adc.h"

#include "gpio_config.h"

#define PWM0_PIN 26
#define PWM1_PIN 27
#define PWM2_PIN 14
#define PWM3_PIN 13
#define AIR_PWM_MAX_VALUE 0x03FF
#define AIR_PWM_MIN_VALUE 0x0000
#define PIN_MAX_VALUE 48

void AIR_GPIO_InterruptHandler(void* parameter, UINT8 u8);

//This is our inturrupt call back vector table
//So all pins could have their own unique callback functions addressed out.
static air_gpio_callback_func_ptr inturruptVectorTable[] = {
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};

static UINT16 interrupt_handler_mask[3] = {0, 0, 0};

int BCM20737ToAir(int bcmMode)
{
	int airMode = 0x0000;
	
	switch(bcmMode & (GPIO_OUTPUT_ENABLE | GPIO_PULL_DOWN | GPIO_PULL_UP | GPIO_INTERRUPT_ENABLE_MASK | GPIO_EN_INT_MASK))
	{
		case GPIO_PULL_UP | GPIO_INPUT_ENABLE:
			airMode = AIR_GPIO_INPUT_PULL_UP;
			break;
			
		case GPIO_PULL_DOWN | GPIO_INPUT_ENABLE:
			airMode = AIR_GPIO_INPUT_PULL_DOWN;
			break;
			
		case GPIO_INPUT_ENABLE:
			airMode = AIR_GPIO_INPUT_HIGH_IMPEDANCE;
			break;
			
		case GPIO_OUTPUT_ENABLE:
			airMode = AIR_GPIO_OUTPUT_OPEN_DRAIN_NO_PULL;
			break;
			
		case GPIO_PULL_UP | GPIO_OUTPUT_ENABLE:
			airMode = AIR_GPIO_OUTPUT_OPEN_DRAIN_PULL_UP;
			break;
			
		case GPIO_PULL_DOWN | GPIO_OUTPUT_ENABLE:
			airMode = AIR_GPIO_OUTPUT_PUSH_PULL;
			break;
			
		case GPIO_PULL_UP | GPIO_INPUT_ENABLE | GPIO_EN_INT_RISING_EDGE:
			airMode = AIR_GPIO_TRIGGER_RISING_EDGE;
			break;
			
		case GPIO_PULL_UP | GPIO_INPUT_ENABLE | GPIO_EN_INT_FALLING_EDGE:
			airMode = AIR_GPIO_TRIGGER_FALLING_EDGE;
			break;
			
		case GPIO_PULL_UP | GPIO_INPUT_ENABLE | GPIO_EN_INT_BOTH_EDGE:
			airMode = AIR_GPIO_TRIGGER_BOTH_EDGES;
			break;
	}
	
	return airMode;
}

int airToBCM20737(int airMode)
{
	int bcmMode = 0x0000;
	
	switch(airMode)
	{
		case AIR_GPIO_INPUT_PULL_UP:
			bcmMode = GPIO_PULL_UP | GPIO_INPUT_ENABLE;
			break;
			
		case AIR_GPIO_INPUT_PULL_DOWN:
			bcmMode = GPIO_PULL_DOWN | GPIO_INPUT_ENABLE;
			break;
			
		case AIR_GPIO_INPUT_HIGH_IMPEDANCE:
			bcmMode = GPIO_INPUT_ENABLE;
			break;
			
		case AIR_GPIO_OUTPUT_OPEN_DRAIN_NO_PULL:
			bcmMode = GPIO_OUTPUT_ENABLE;
			break;
		case AIR_GPIO_OUTPUT_OPEN_DRAIN_PULL_UP:
			bcmMode = GPIO_PULL_UP | GPIO_OUTPUT_ENABLE;
			break;
			
		case AIR_GPIO_OUTPUT_PUSH_PULL:
			bcmMode = GPIO_PULL_DOWN | GPIO_OUTPUT_ENABLE;
			break;
	}
	
	return bcmMode;
}

int airIntToBCM20737(int airMode)
{
	int bcmMode = 0x0000;
	
	switch(airMode)
	{
		case AIR_GPIO_TRIGGER_RISING_EDGE:
			bcmMode = GPIO_PULL_UP | GPIO_INPUT_ENABLE | GPIO_EN_INT_RISING_EDGE;
			break;
			
		case AIR_GPIO_TRIGGER_FALLING_EDGE:
			bcmMode = GPIO_PULL_UP | GPIO_INPUT_ENABLE | GPIO_EN_INT_FALLING_EDGE;
			break;
			
		case AIR_GPIO_TRIGGER_BOTH_EDGES:
			bcmMode = GPIO_PULL_UP | GPIO_INPUT_ENABLE | GPIO_EN_INT_BOTH_EDGE;
			break;
	}
	
	return bcmMode;
}

void AIR_GPIO_Init()
{
	//gpio_init();
	//adc_config();

	adc_setAdcSampleFrequency(AIR_ADC_SAMPLE_FREQUENCY);
}

void AIR_GPIO_SetMode(unsigned int pin, int mode)
{
	switch(pin) 
	{
		case 8:
			gpio_configurePin(33 / 16, 33 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 11:
			gpio_configurePin(27 / 16, 27 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
		
		case 12:
			gpio_configurePin(26 / 16, 26 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 13:
			gpio_configurePin(28 / 16, 28 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 14:
			gpio_configurePin(38 / 16, 38 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 26:
			gpio_configurePin(12 / 16, 12 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 27:
			gpio_configurePin(11 / 16, 11 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 28:
			gpio_configurePin(13 / 16, 13 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 33:
			gpio_configurePin(8 / 16, 8 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
			
		case 38:
			gpio_configurePin(14 / 16, 14 % 16, airToBCM20737(AIR_GPIO_INPUT_HIGH_IMPEDANCE), 0);
			break;
	}
	
	gpio_configurePin(pin / 16, pin % 16, airToBCM20737(mode), 0);
}

int AIR_GPIO_GetMode(unsigned int pin)
{
	return BCM20737ToAir(gpio_getPinConfig(pin / 16, pin % 16));
}

bool AIR_GPIO_Read(unsigned int pin)
{
	if(gpio_getPinConfig(pin / 16, pin % 16) & GPIO_OUTPUT_ENABLE == GPIO_OUTPUT_ENABLE)
	{
		return gpio_getPinOutput(pin / 16, pin % 16);
	}
	
	else
	{
		return gpio_getPinInput(pin / 16, pin % 16);
	}
}

void AIR_GPIO_Write(unsigned int pin, bool value)
{
	//TODO: Check the pins configuration to determine if it is set for OUTPUT
	
	gpio_setPinOutput(pin / 16, pin % 16, value);
}

void AIR_GPIO_RegisterInterrupt(unsigned int pin, air_gpio_callback_func_ptr func, int flags)
{
	if(pin > PIN_MAX_VALUE)
	{
		return;
	}
	
	inturruptVectorTable[pin] = func;
	
	gpio_configurePin(pin / 16, pin % 16, airIntToBCM20737(flags), 0);
	interrupt_handler_mask[pin / 16] |= (1 << (pin % 16));
	gpio_registerForInterrupt(interrupt_handler_mask, AIR_GPIO_InterruptHandler, NULL);
}


void AIR_PWM_Enable(unsigned int pin)
{
	switch(pin)
	{
		case PWM1_PIN:
			pwm_start(PWM1, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE, 0);
			break;
			
		case PWM0_PIN:
			pwm_start(PWM0, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE, 0);
			break;
			
		case PWM3_PIN:
			pwm_start(PWM3, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE | (1 << 5), 0);
			break;
			
		case PWM2_PIN:
			pwm_start(PWM2, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE | (1 << 5), 0);
			break;
			
		default:
			return;
	}
}

void AIR_PWM_Configure(unsigned int pin, unsigned int toggleCount, unsigned int initCount)
{
	switch(pin)
	{
		case PWM1_PIN:
			pwm_start(PWM1, PMU_CLK, toggleCount, initCount);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE, 0);
			break;
			
		case PWM0_PIN:
			pwm_start(PWM0, PMU_CLK, toggleCount, initCount);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE, 0);
			break;
			
		case PWM3_PIN:
			pwm_start(PWM3, PMU_CLK, toggleCount, initCount);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE | (1 << 5), 0);
			break;
			
		case PWM2_PIN:
			pwm_start(PWM2, PMU_CLK, toggleCount, initCount);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_ENABLE | (1 << 5), 0);
			break;
			
		default:
			return;
	}
}

void AIR_PWM_Disable(unsigned int pin)
{
	switch(pin)
	{
		case PWM1_PIN:
			pwm_start(PWM1, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_DISABLE, 0);
			break;
			
		case PWM0_PIN:
			pwm_start(PWM0, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_DISABLE, 0);
			break;
			
		case PWM3_PIN:
			pwm_start(PWM3, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_DISABLE | (1 << 5), 0);
			break;
			
		case PWM2_PIN:
			pwm_start(PWM2, PMU_CLK, AIR_PWM_MIN_VALUE, AIR_PWM_MAX_VALUE);
			gpio_configurePin(pin / 16, pin % 16, GPIO_OUTPUT_DISABLE | (1 << 5), 0);
			break;
			
		default:
			return;
	}
}

void AIR_PWM_SetAdv(unsigned int pin, int toggleCount, int initCount)
{
	if(!(toggleCount >= AIR_PWM_MIN_VALUE & toggleCount <= AIR_PWM_MAX_VALUE))
	{
		return;
	}
	
	switch(pin)
	{
		case PWM1_PIN:
			pwm_transitionToSubstituteValues(PWM1, toggleCount, initCount);
			break;
			
		case PWM0_PIN:
			pwm_transitionToSubstituteValues(PWM0, toggleCount, initCount);
			break;
			
		case PWM3_PIN:
			pwm_transitionToSubstituteValues(PWM3, toggleCount, initCount);
			break;
			
		case PWM2_PIN:
			pwm_transitionToSubstituteValues(PWM2, toggleCount, initCount);
			break;
			
		default:
			return;
	}
}

void AIR_PWM_Set(unsigned int pin, int toggleCount)
{
	AIR_PWM_SetAdv(pin, toggleCount, AIR_PWM_MIN_VALUE);
}

void AIR_PWM_Change(unsigned int pin, int toggleCount)
{
	if(!(toggleCount >= AIR_PWM_MIN_VALUE & toggleCount <= AIR_PWM_MAX_VALUE))
	{
		return;
	}
	
	switch(pin)
	{
		case PWM1_PIN:
			pwm_startWithAlternateValues(PWM1, PMU_CLK, toggleCount & AIR_PWM_MAX_VALUE, AIR_PWM_MIN_VALUE, false);
			break;
			
		case PWM0_PIN:
			pwm_startWithAlternateValues(PWM0, PMU_CLK, toggleCount & AIR_PWM_MAX_VALUE, AIR_PWM_MIN_VALUE, false);
			break;
			
		case PWM3_PIN:
			pwm_startWithAlternateValues(PWM3, PMU_CLK, toggleCount & AIR_PWM_MAX_VALUE, AIR_PWM_MIN_VALUE, false);
			break;
			
		case PWM2_PIN:
			pwm_startWithAlternateValues(PWM2, PMU_CLK, toggleCount & AIR_PWM_MAX_VALUE, AIR_PWM_MIN_VALUE, false);
			break;
			
		default:
			return;
	}
}

void AIR_ADC_Enable(unsigned int pin)
{
	gpio_configurePin(pin / 16, pin % 16, GPIO_INPUT_ENABLE | GPIO_INIT_LOW, 0);
}

void AIR_ADC_SetReferenceVoltage(unsigned int pin, unsigned int millivolts)
{
	adc_adcCalibrate(millivolts, adc_convertGPIOtoADCInput(pin));
}

unsigned int AIR_ADC_Read(unsigned int pin)
{
	return adc_readVoltage(adc_convertGPIOtoADCInput(pin));
}

int AIR_ADC_ReadRaw(unsigned int pin)
{
	return adc_readSampleRaw(adc_convertGPIOtoADCInput(pin));
}

void AIR_GPIO_InterruptHandler(void* parameter, UINT8 u8)
{
	int intStatus[] = {	gpio_getPortInterruptStatus(0),
				gpio_getPortInterruptStatus(1),
				gpio_getPortInterruptStatus(2)
	};
	
	int port;
	int slot;
	
	//This is a pretty sloppy way of finding which pins is currently active in the inturrupt
	for(port = 0; port < 3; port++)
	{
		for(slot = 0; slot < 16; slot++)
		{
			if((intStatus[port] >> slot) & 0x1)
			{
				if(inturruptVectorTable[(port * 16) + slot] != NULL)
				{
					inturruptVectorTable[(port * 16) + slot](); //Execute the callback from the vector table
				}
			}
		}
	}
}