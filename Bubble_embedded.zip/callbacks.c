#include "callbacks.h"
//#include "hmc5883/hmc5883.h"
#include "lis3dh/lis3dh.h"
//#include "tmp006/tmp006.h"
//#include "xra1201/xra1201.h"

static char valuesBuffer[256];
int currentX = 0;
int currentY = 0;

#define BUBBLE_BORDER_WIDTH 58
#define BUBBLE_BORDER_HEIGHT 58
#define BUBBLE_ACCELERATION 200
#define JOYSTICK_MOVE_LENGTH 20

char buffer[128];
int bubbleWidth = 256;
int bubbleHeight = 256;

//END


void interval() {
BUZZER_Stop();
    
    int16 x = LIS3DH_GetXaxisRaw();
    int16 y = LIS3DH_GetYaxisRaw();
    int16 z = LIS3DH_GetZaxisRaw();

    currentX = currentX + (y / -200);
    currentY = currentY + (x / -200);
    
    if(currentX < -256) {
        currentX = -256;
    }
    
    if(currentX > 256) {
        currentX = 256;
    }
    
    if(currentY < -256) {
        currentY = -256;
    }
    
    if(currentY > 256) {
        currentY = 256;
    }

    sprintf(buffer, "[%d, %d, %d, %d, %d, %d]", x, y, z, 0, 0, 0);
}


void connected() {

}


void disconnected() {

}


void setup() {
	AIR_GPIO_Init();
	AIR_POWER_Init();
	AIR_UART_Init();
	AIR_I2C_Init();
	AIR_SPI_Init();
	BUZZER_Init();
	LIS3DH_Init();
	
	AIR_POWER_SetMode(AIR_POWER_NOSLEEP);
	
	AIR_GPIO_SetMode(13, AIR_GPIO_OUTPUT_OPEN_DRAIN_NO_PULL);
	AIR_GPIO_Write(13, 0);

    //HMC5883_SetNumberSamplesAveraged(HMC5883_AVGSMPL_8);
    //HMC5883_SetGain(HMC5883_GAIN_1370);
    //HMC5883_SetOperatingMode(HMC5883_CONTINUOUSMEASUREMENT);
    
    //XRA1201_SetInputPolarityInversion(17, 0xFFFF);     	// invert all pins so that the active low inputs read back as logic '1'
    //XRA1201_SetInterruptFilterEnable(17, 0xFFFF);       // enable input filter on all pins
    //XRA1201_SetInterruptEnable(17, 0x0000);             // disable all inturrupts
    //XRA1201_GetGpioState(17);
    
    //TMP006_SetDataReadyEnable(0, 1);
	

}


char *Function4(char *data, int length)
{

	return buffer;
	
}

char *PPWMSet23(char *data, int length)
{


	
	AIR_PWM_Enable(27);
	
	int i = 0;
	unsigned int value = 0;
	int m = 1;
	
	if(data[0] == 't')
		value = 0x0000;
	
	else if(data[0] == 'f')
		value = 0x03FF;
		
	
	else if(data[length - 1] >= '0' && data[length - 1] <= '9')
	{
		for(i = length - 1; i >= 0; i--)
		{
			if(data[i] >= '0' && data[i] <= '9')
			{
				value = value + ((data[i] - '0') * m);
				m = m * 10;
			}
		}
		
		unsigned int step = 0x3FF/20;
		
		value = 0x3FF - (step * value);
	}
	
	AIR_PWM_Set(27, value);
	
	return NULL;
	
	
}

char *PWMSet21(char *data, int length)
{

	AIR_PWM_Enable(26);
	
	int i = 0;
	unsigned int value = 0;
	int m = 1;
	
	if(data[0] == 't')
		value = 0x0000;
	
	else if(data[0] == 'f')
		value = 0x03FF;
		
	
	else if(data[length - 1] >= '0' && data[length - 1] <= '9')
	{
		for(i = length - 1; i >= 0; i--)
		{
			if(data[i] >= '0' && data[i] <= '9')
			{
				value = value + ((data[i] - '0') * m);
				m = m * 10;
			}
		}
		
		unsigned int step = 0x3FF/20;
		
		value = 0x3FF - (step * value);
	}
	
	AIR_PWM_Set(26, value);
	
	return NULL;
	
}

char *PWMSet22(char *data, int length)
{


	AIR_PWM_Enable(13);
	
	int i = 0;
	unsigned int value = 0;
	int m = 1;
	
	if(length > 0)
	{
		if(data[0] == 't')
			value = 0x0000;
		
		else if(data[0] == 'f')
			value = 0x03FF;
			
		
		else if(data[length - 1] >= '0' && data[length - 1] <= '9')
		{
			for(i = length - 1; i >= 0; i--)
			{
				if(data[i] >= '0' && data[i] <= '9')
				{
					value = value + ((data[i] - '0') * m);
					m = m * 10;
				}
			}
			
			unsigned int step = 0x3FF/20;
			
			value = 0x3FF - (step * value);
		}
		
		AIR_PWM_Set(13, value);
	}
	
	return NULL;
	
	
}

