#include "power.h"
#include "bleprofile.h"
#include "bleapp.h"
#include "string.h"
#include "stdio.h"
#include "bleappconfig.h"
#include "cfa.h"
#include "devicelpm.h"

static AIR_POWER_Mode currentSleepMode = AIR_POWER_NOSLEEP;

// This callback function is expected to respond with time to
/// sleep or if it is ok to enter hid off or not. A 0 value indicates
/// do not sleep or do not go hid-off and a non-zero value for sleep is the sleep time
/// or ok to go hid-off
UINT32 air_power_lpm_queriable(LowPowerModePollType type, UINT32 context)
{
	switch(type)
	{
		case LOW_POWER_MODE_POLL_TYPE_SLEEP:
			if(currentSleepMode == AIR_POWER_SLEEP || currentSleepMode == AIR_POWER_OFF)
			{
				return ~0;
			}
			
			break;
			
		case LOW_POWER_MODE_POLL_TYPE_POWER_OFF:
			if(currentSleepMode == AIR_POWER_OFF)
			{
				return 1;
			}
			
			else
			{
				return 0;
			}
			
			break;
	}
	
	return 0;
}

void AIR_POWER_Init()
{
	devlpm_init();
	devlpm_registerForLowPowerQueries(air_power_lpm_queriable, 2);
}

void AIR_POWER_SetMode(AIR_POWER_Mode mode)
{
	currentSleepMode = mode;
	
	if(currentSleepMode == AIR_POWER_OFF)
	{
		bleapputils_delayUs(500);
		// Set the device to sleep now
		bleprofile_PrepareHidOff();              //Puts device into Deep Sleep ~1.33uA
		devlpm_timeToSleep();
	}
}

AIR_POWER_Mode AIR_POWER_GetMode()
{
	return currentSleepMode;
}
