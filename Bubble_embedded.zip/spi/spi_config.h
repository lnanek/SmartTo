#define AIR_SPI_SPEED                           1000000
#define AIR_SPI_SCLK_PIN			3
#define AIR_SPI_MOSI_PIN			4
#define AIR_SPI_MISO_PIN			25
#define AIR_SPI_SS_PIN				24