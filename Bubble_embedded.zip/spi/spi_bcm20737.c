#include "spi.h"
#include "types.h"
#include "bleprofile.h"
#include "bleapp.h"
#include "gpiodriver.h"
#include "spiffydriver.h"

#define AIR_SPI_CS_ASSERT                       0
#define AIR_SPI_CS_DEASSERT                     1

void AIR_SPI_Init()
{
	spi2PortConfig.masterOrSlave = MASTER2_CONFIG;
	spi2PortConfig.pinPullConfig = INPUT_PIN_PULL_UP;
	spi2PortConfig.spiGpioConfig = MASTER2_P24_CLK_P04_MOSI_P25_MISO;
	spiffyd_init(SPIFFYD_2);
	spiffyd_configure(SPIFFYD_2, AIR_SPI_SPEED, SPI_MSB_FIRST, SPI_SS_ACTIVE_LOW, SPI_MODE_3);
}

void AIR_SPI_SetCSPin(int cspin)
{
	gpio_configurePin(cspin / 16, cspin % 16, GPIO_OUTPUT_ENABLE | GPIO_INPUT_DISABLE, AIR_SPI_CS_DEASSERT);
}

void AIR_SPI_AssertCSPin(int cspin)
{ 
	if(cspin >= 0)
	{
		gpio_setPinOutput(cspin / 16, cspin % 16, AIR_SPI_CS_ASSERT);
	}
}

void AIR_SPI_DeassertCSPin(int cspin)
{
	if(cspin >= 0)
	{
		gpio_setPinOutput(cspin / 16, cspin % 16, AIR_SPI_CS_DEASSERT);
	}
}

void AIR_SPI_Write(int cspin, unsigned char *writeBytes, unsigned int numWriteBytes)
{
	AIR_SPI_AssertCSPin(cspin);
	spiffyd_txData(SPIFFYD_2, numWriteBytes, writeBytes);
	AIR_SPI_DeassertCSPin(cspin);
}

void AIR_SPI_Read(int cspin, unsigned char *readBytes, unsigned int numReadBytes)
{
	AIR_SPI_AssertCSPin(cspin);
	spiffyd_rxData(SPIFFYD_2, numReadBytes, readBytes);
	AIR_SPI_DeassertCSPin(cspin);
}

void AIR_SPI_Exchange(int cspin, unsigned char *readBytes, unsigned char *writeBytes, unsigned int numberOfBytes)
{
	AIR_SPI_AssertCSPin(cspin);
	spiffyd_exchangeData(SPIFFYD_2, numberOfBytes, writeBytes, readBytes);
	AIR_SPI_DeassertCSPin(cspin);
}