// Copyright (c) 2014, Anaren Inc.
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer. 
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies, 
// either expressed or implied, of the FreeBSD Project.

#ifndef AIR_SPI_H
#define AIR_SPI_H

#include "spi_config.h"

/**
 * AIR_SPI_Init will initialize the microcontroller's hardware to enable it for SPI communication
 * This function must be executed before any other SPI function is used.
 */
void AIR_SPI_Init();

/**
 * AIR_SPI_SetCSPin will enable a particular pin on the board to be enabled for use a chip select pin.
 * In most cases this pin will be a standard GPIO output but refer to your modules manual for more information.
 */
void AIR_SPI_SetCSPin(int cspin);

/**
 * AIR_SPI_AssertCSPin will assert a pin that has been configured to be a chip select pin to so that communication over SPI to the target SPI device can begin.
 * Note you must have configured the pin with AIR_SPI_SetCSPin before you attempt to use this function
 */
void AIR_SPI_AssertCSPin(int cspin);

/**
 * AIR_SPI_DeassertCSPin will deassert a pin that has been configured to be a chip select pin so that communication over SPI to the target SPI device is stopped.
 * Note you must have configured the pin with AIR_SPI_SetCSPin before you attempt to use this function
 */
void AIR_SPI_DeassertCSPin(int cspin);

/**
 * AIR_SPI_Write will assert the chip select pin for a target SPI device and then write out a series of bytes to the target device
 * All inbound information from the target device will be ignored.
 * If you select a negative number pin for the chip select then a pin will not be asserted and deasserted for the chip select.
 */
void AIR_SPI_Write(int cspin, unsigned char *writeBytes, unsigned int numWriteBytes);

/**
 * AIR_SPI_Write will assert the chip select pin for a target SPI device and then read in a series of bytes from the target device
 * There will be no outbound traffic to the target device.
 * If you select a negative number pin for the chip select then a pin will not be asserted and deasserted for the chip select.
 */
void AIR_SPI_Read(int cspin, unsigned char *readBytes, unsigned int numReadBytes);

/**
 * AIR_SPI_Exchange will assert a chip select pin for a target SPI device and then read and write from the target device
 * If you select a negative number pin for the chip select then a pin will not be asserted and deasserted for the chip select.
 */
void AIR_SPI_Exchange(int cspin, unsigned char *readBytes, unsigned char *writeBytes, unsigned int numberOfBytes);

#endif /* AIR_SPI_H */