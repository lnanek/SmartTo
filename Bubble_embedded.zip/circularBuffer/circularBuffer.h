// Copyright (c) 2014, Anaren Inc.
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer. 
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies, 
// either expressed or implied, of the FreeBSD Project.

#ifndef CIRCULAR_BUFFER_H
#define CIRCULAR_BUFFER_H

#define CIRCULAR_BUFFER "1.0.00"

#ifndef bool
#define bool unsigned char
#define true 1
#define false 0
#endif

#ifndef NULL
#define NULL  (void*)0
#endif

// -----------------------------------------------------------------------------
/**
 *  Defines, enumerations, and structure definitions
 */

///**
// *  sCircularBufferCriticalRegion - represents a circular buffer critical
// *  region. This area must be performed in an "atomic" instruction (cannot be
// *  interrupted). Enter represents disabling interrupts, while Exit represents
// *  reissuing the state that the system was in prior to disabling interrupts.
// */
//struct sCircularBufferCriticalRegion
//{
//  unsigned int(*const Enter)(void);
//  void(*const Exit)(unsigned int);
//};

/**
 *  sCircularBuffer - represents a circular buffer.
 */
struct sCircularBuffer
{
//  const struct sCircularBufferCriticalRegion *criticalRegion;
	unsigned char *start;
	unsigned char *end;
	unsigned char *write;
	unsigned char *read;
};

// -----------------------------------------------------------------------------
/**
 *  Global data
 */

// -----------------------------------------------------------------------------
/**
 *  Public Interface
 */
#define CircularBuffer_IsEmpty(cb) ((cb->write == cb->read) ? true : false)

/**
 *   CircularBufferIsFull
 */
bool CircularBuffer_IsFull(struct sCircularBuffer *cb);

/**
 *  CircularBufferInit - initialize a circular buffer instance.
 *
 *  Note: This implementation of a circular buffer keeps one slot open. It is
 *  assumed that the buffer used to create a circular buffer is one byte bigger
 *  than what is actually needed. This last byte becomes "wasted" and is used
 *  to differentiate between empty and full states.
 *
 *    @param  cb      The circular buffer instance being initialized.
 *    @param  buffer  Buffer to be used as a circular buffer. The last byte in
 *                    the buffer is used to differentiate between empty and full
 *                    states.
 *    @param  size    Size of the usuable buffer.
 */
void CircularBuffer_Init(struct sCircularBuffer *cb,
				unsigned char *buffer,
				unsigned char size);

/**
 *  CircularBufferWrite - write a byte to the circular buffer.
 *
 *    @param  cb        The circular buffer that is being written to.
 *    @param  writeByte Byte to be written to the circular buffer.
 *
 *    @return Circular buffer full indicator. When full, CircularBufferWrite
 *            returns "true". This indicates that the circular buffer is full
 *            and that a new byte could not be written.
 */
bool CircularBuffer_Write(struct sCircularBuffer *cb,
				unsigned char writeByte);

/**
 *  CircularBufferRead - read a byte from the circular buffer.
 *
 *    @param  cb        The circular buffer that is being read from.
 *    @param  readByte  Byte to be read from the circular buffer.
 *
 *    @return Circular buffer empty indicator. When empty, CircularBufferRead
 *            returns "true". This indicates that the circular buffer is empty
 *            and that a byte could not be read.
 */
bool CircularBuffer_Read(struct sCircularBuffer *cb,
				unsigned char *readByte);

#endif  /* CIRCULAR_BUFFER_H */
