
void anaren_return_char(LEGATTDB_ENTRY_HDR *p, char value, UINT8 *attrPtr)
{
	attrPtr[0] = value;
	
	legattdb_setAttrValueLen(p, 1);
}

void anaren_return_bool(LEGATTDB_ENTRY_HDR *p, char value, UINT8 *attrPtr)
{
	attrPtr[0] = value;
	
	legattdb_setAttrValueLen(p, 1);
}

void anaren_return_int(LEGATTDB_ENTRY_HDR *p, int value, UINT8 *attrPtr)
{
	union {
		int variable;
		unsigned char temp_array[4];
	} u;
	
	u.variable = value;
	
	memcpy(attrPtr, u.temp_array, 4);
	
	legattdb_setAttrValueLen(p, 4);
}

void anaren_return_float(LEGATTDB_ENTRY_HDR *p, float value, UINT8 *attrPtr)
{
	union {
		float variable;
		unsigned char temp_array[4];
	} u;
	
	u.variable = value;
	
	memcpy(attrPtr, u.temp_array, 4);
	
	legattdb_setAttrValueLen(p, 4);
}

void anaren_return_double(LEGATTDB_ENTRY_HDR *p, double value, UINT8 *attrPtr)
{
	union {
		double variable;
		unsigned char temp_array[8];
	} u;
	
	u.variable = value;
	
	memcpy(attrPtr, u.temp_array, 8);
	
	legattdb_setAttrValueLen(p, 8);
}

void anaren_return_string(LEGATTDB_ENTRY_HDR *p, char *data, UINT8 *attrPtr, unsigned int length)
{
	int i = 0;

	if(data != NULL)
	{
		for(i = 0; i < length; i++)
		{
			if(data[i] == 0)
			{
				attrPtr[i] = data[i];
				break;
			}
			
			attrPtr[i] = data[i];
		}
	}
	
	legattdb_setAttrValueLen(p, i);
}
	
void anaren_return_json(LEGATTDB_ENTRY_HDR *p, char *jsonData, UINT8 *attrPtr, unsigned int length)
{
	int i = 0;

	if(jsonData != NULL)
	{
		attrPtr[0] = 0x04;
		attrPtr[1] = attrPtr[1];
	
		for(i = 2; i < length; i++)
		{
			if(jsonData[i - 2] == 0)
			{
				attrPtr[i] = jsonData[i - 2];
				break;
			}
			
			attrPtr[i] = jsonData[i - 2];
		}
	}
	
	legattdb_setAttrValueLen(p, i + 1);
}

char anaren_make_char(UINT8 *attrPtr)
{
	return (char)attrPtr[0];
}

int anaren_make_int(UINT8 *attrPtr)
{
	union {
		int variable;
		unsigned char temp_array[4];
	} u;
	
	memcpy(u.temp_array, attrPtr, 4);
	
	return u.variable;
}

float anaren_make_float(UINT8 *attrPtr)
{
	union {
		float variable;
		unsigned char temp_array[4];
	} u;
	
	memcpy(u.temp_array, attrPtr, 4);
	
	return u.variable;
}

double anaren_make_double(UINT8 *attrPtr)
{
	union {
		double variable;
		unsigned char temp_array[8];
	} u;
	
	memcpy(u.temp_array, attrPtr, 8);
	
	return u.variable;
}

int anaren_control_write_handler(LEGATTDB_ENTRY_HDR *p)
{
	UINT16 handle = legattdb_getHandle(p);
	int len = legattdb_getAttrValueLen(p);
	UINT8  *attrPtr = legattdb_getAttrValue(p);

	switch(handle)
	{

		case ATMOSPHERE_NOTIFY_DESCRIPTOR_HANDLE:
			if(len == 2)
			{
				anaren_control_hostinfo.characteristic_client_configuration = attrPtr[0] + (attrPtr[1] << 8);
				return 0;
			}

			return 0x80;
		break;

		case 0x13:
		{
			attrPtr[len] = 0x00;
			char *retValue = Function4(attrPtr + 3, len - 3);
			anaren_return_json(p, retValue, attrPtr, 0x80);
			
			return 0;
		}
		break;

		case 0x15:
		{
			attrPtr[len] = 0x00;
			char *retValue = PPWMSet23(attrPtr + 3, len - 3);
			anaren_return_json(p, retValue, attrPtr, 0x80);
			
			return 0;
		}
		break;

		case 0x17:
		{
			attrPtr[len] = 0x00;
			char *retValue = PWMSet21(attrPtr + 3, len - 3);
			anaren_return_json(p, retValue, attrPtr, 0x80);
			
			return 0;
		}
		break;

		case 0x19:
		{
			attrPtr[len] = 0x00;
			char *retValue = PWMSet22(attrPtr + 3, len - 3);
			anaren_return_json(p, retValue, attrPtr, 0x80);
			
			return 0;
		}
		break;

		default:
			return 0x80;
		break;
	}
	
	return 0;
}
