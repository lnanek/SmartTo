#include "bleprofile.h"
#include "bleapp.h"
#include "gatt.h"
#include "../air_gatt_defines.h"

#if defined(ATMOSPHERE_GATT_GAP_DEVICE_NAME_HANDLE)
void AIR_GATT_GAP_SetDeviceName(char *name)
{
	if(name == NULL)
		return;
	
	BLEPROFILE_DB_PDU db_pdu;

	db_pdu.len = 16;
	
	unsigned char i;
	
	for(i = 0; i < 16; i++)
	{
		if(name[i] == 0x00) {
			break;
		}
		
		else {
			db_pdu.pdu[i] = name[i];
		}
	}
	
	for(i; i < 16; i++)
	{
		db_pdu.pdu[i] = 0x00;
	}

	bleprofile_WriteHandle(ATMOSPHERE_GATT_GAP_DEVICE_NAME_HANDLE, &db_pdu);
}
#endif

#if defined(ATMOSPHERE_GATT_BATTERY_HANDLE)
void AIR_GATT_BATTERY_SetLevel(char level)
{
	BLEPROFILE_DB_PDU db_pdu;

	db_pdu.len = 1;
	db_pdu.pdu[0] = level;

	bleprofile_WriteHandle(ATMOSPHERE_GATT_BATTERY_HANDLE, &db_pdu);
}

char AIR_GATT_BATTERY_GetLevel()
{
	BLEPROFILE_DB_PDU db_pdu;
	bleprofile_ReadHandle(ATMOSPHERE_GATT_BATTERY_HANDLE, &db_pdu);
	
	return db_pdu.pdu[0];
}

void AIR_GATT_BATTERY_SetAndNotifyLevel(char level)
{
	AIR_GATT_BATTERY_SetLevel(level);
	AIR_GATT_BATTERY_NotifyLevel(level);
}

void AIR_GATT_BATTERY_NotifyLevel(char level)
{
	bleprofile_sendNotification(ATMOSPHERE_GATT_BATTERY_HANDLE, (UINT8 *)&level, 1);
}

void AIR_GATT_BATTERY_NotifyCurrentLevel()
{
	BLEPROFILE_DB_PDU db_pdu;
	bleprofile_ReadHandle(ATMOSPHERE_GATT_BATTERY_HANDLE, &db_pdu);
	AIR_GATT_BATTERY_NotifyLevel(db_pdu.pdu[0]);
}
#endif

#if defined(ATMOSPHERE_GATT_IMMEDIATE_ALERT_HANDLE)

static air_immediate_alert_callback_func_ptr immediateAlertCallback = NULL;

void AIR_GATT_IMMEDIATE_ALERT_RegisterCallback(air_immediate_alert_callback_func_ptr func)
{
	immediateAlertCallback = func;
}

void AIR_GATT_IMMEDIATE_ALERT_ExecuteCallback(unsigned char data)
{
	AIR_GATT_IMMEDIATE_ALERT_Type alertType = AIR_GATT_IMMEDIATE_ALERT_RESERVED;
	
	if(data == 0)
	{
		alertType = AIR_GATT_IMMEDIATE_ALERT_NO_ALERT;
	}
	
	else if(data == 1)
	{
		alertType = AIR_GATT_IMMEDIATE_ALERT_MILD_ALERT;
	}
	
	else if(data == 2)
	{
		alertType = AIR_GATT_IMMEDIATE_ALERT_HIGH_ALERT;
	}
	
	if(immediateAlertCallback != NULL)
	{
		immediateAlertCallback(alertType);
	}
}

#endif