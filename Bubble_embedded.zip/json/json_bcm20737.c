
#include "json.h"
#include "string.h"
#include "stdio.h"
#include "spar_utils.h"

static char jsonRetBuffer[JSON_RET_BUFFER_SIZE];
static int jsonError = 0;

void JSON_Init()
{
	jsonError = JSON_NO_ERROR;
}

int JSON_GetError()
{
	return jsonError;
}

int JSON_ReadInt(char *jsonString)
{
	unsigned int i = 0;
	bool negative = false;
	int value = 0;
	
	for(; jsonString[i] != '\0'; i++)
	{
		if(jsonString[i] >= '0' && jsonString[i] <= '9')
		{
			value = value * 10;
			value = value + (jsonString[i] - '0');
		}
		
		else if(jsonString[i] == '-')
		{
			if(i == 0)
			{
				negative = true;
			}
			
			else
			{
				goto parse_failed;
			}
		}
		
		else
		{
			goto parse_failed;
		}	
	}
	
	jsonError = JSON_NO_ERROR;
	
	if(negative)
	{
		return value * -1;
	}
	
	else
	{
		return value;
	}
	
	parse_failed:
		jsonError = JSON_PARSING_ERROR;
		return 0;
}

float JSON_ReadFloat(char *jsonString)
{
	unsigned int i = 0;
	bool negative = false;
	bool tokenDecimal = false;
	float value = 0.0f;
	float m = 0.1f;
	
	for(; jsonString[i] != '\0'; i++)
	{
		if(jsonString[i] >= '0' && jsonString[i] <= '9')
		{
			if(!tokenDecimal)
			{
				value = value * 10.0f;
				value = value + (float)(jsonString[i] - '0');
			}
			
			else
			{
				value = value + ((float)(jsonString[i] - '0') * m);
				m = m * 0.1;
			}
		}
		
		else if(jsonString[i] == '-')
		{
			if(i == 0)
			{
				negative = true;
			}
			
			else
			{
				goto parse_failed;
			}
		}
		
		else if(jsonString[i] == '.')
		{
			if(tokenDecimal)
			{
				goto parse_failed;
			}
			
			else
			{
				tokenDecimal = true;
			}
		}
		
		else
		{
			goto parse_failed;
		}	
	}
	
	jsonError = JSON_NO_ERROR;
	
	if(negative)
	{
		return value * -1.0f;
	}
	
	else
	{
		return value;
	}
	
	parse_failed:
		jsonError = JSON_PARSING_ERROR;
		return 0.0f;
}

char *JSON_ReadString(char *jsonString)
{
	unsigned int i = 0;
	unsigned int j = 0;
	
	bool tokenStarted = false;
	bool tokenEnded = false;
	
	for(; j < JSON_RET_BUFFER_SIZE && !tokenEnded; i++)
	{
		switch(jsonString[i])
		{	
			case '\0':
				goto parse_failed;
				break;
			
			case '"':
				if(!tokenStarted)
				{
					tokenStarted = true;
				}
				
				else
				{
					tokenEnded = true;
				}
				
				break;
				
			case '\\':
			{
				if(!tokenStarted)
					goto parse_failed;
				
				switch(jsonString[++i])
				{
					case '"':
						jsonRetBuffer[j] = '"';
						j++;
						break;
						
					case '/':
						jsonRetBuffer[j] = '/';
						j++;
						break;
						
					case 'b':
						jsonRetBuffer[j] = '\b';
						j++;
						break;
						
					case 'f':
						jsonRetBuffer[j] = '\f';
						j++;
						break;
						
					case 'n':
						jsonRetBuffer[j] = '\n';
						j++;
						break;
						
					case 'r':
						jsonRetBuffer[j] = '\r';
						j++;
						break;
						
					case 't':
						jsonRetBuffer[j] = '\t';
						j++;
						break;
						
					case '\\':
						jsonRetBuffer[j] = '\\';
						j++;
						break;
						
					default:
						goto parse_failed;
						break;
				}
				
				break;
			}
			
			default:
				if(!tokenStarted)
					goto parse_failed;
				
				jsonRetBuffer[j] = jsonString[i];
				j++;
				break;
		}
	}
	
	if(j < JSON_RET_BUFFER_SIZE - 1) {
		jsonRetBuffer[j] = '\0';
	}
	
	else {
		jsonRetBuffer[JSON_RET_BUFFER_SIZE - 1] = '\0';
		jsonError = JSON_RETURN_TO_LARGE;
		return NULL;
	}
	
	jsonError = JSON_NO_ERROR;
	
	return jsonRetBuffer;
	
	parse_failed:
		jsonError = JSON_PARSING_ERROR;
		return NULL;
}

bool JSON_ReadBoolean(char *jsonString)
{
#ifdef JSON_QUICK_AND_DIRTY
	jsonError = JSON_NO_ERROR;
	
	if(jsonString[0] == 't')
	{
		return true;
	}
	
	else if(jsonString[1] == 'f')
	{
		return false;
	}
	
	else
	{
		jsonError = JSON_PARSING_ERROR;
		return false;
	}
#else
	jsonError = JSON_MISSING_CAPABILITY;

	return false;
#endif
}

char *JSON_WriteInt(int value)
{
	jsonError = JSON_NO_ERROR;
	
	sprintf(jsonRetBuffer, "%d", value);
	return jsonRetBuffer;
}

char *JSON_WriteFloat(int value)
{
#ifdef JSON_QUICK_AND_DIRTY
	jsonError = JSON_NO_ERROR;
	
	sprintf(jsonRetBuffer, "%d.%d%d%d%d", 
		(int)value, 
		(int)(value * 10.0f) - (int)value * 10,
		(int)(value * 100.0f) - (int)value * 100,
		(int)(value * 1000.0f) - (int)value * 1000,
		(int)(value * 10000.0f) - (int)value * 10000);

	return jsonRetBuffer;
#else
	jsonError = JSON_MISSING_CAPABILITY;
	
	return NULL;
#endif
}

char *JSON_WriteString(char *string)
{
	unsigned int i = 0;
	unsigned int j = 0;
	
	jsonRetBuffer[j] = '"';
	
	j++;
	
	for(; j < JSON_RET_BUFFER_SIZE - 2; i++)
	{
		switch(string[i])
		{
			case '\0':
				jsonRetBuffer[j] = '"';
				jsonRetBuffer[j + 1] = '\0';
				j = j + 2;
			
			case '\\':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = '\\';
				j = j + 2;
				break;
			
			case '\"':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = '\"';
				j = j + 2;
				break;
				
			case '/':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = '/';
				j = j + 2;
				break;
				
			case '\b':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = 'b';
				j = j + 2;
				break;
				
			case '\f':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = 'f';
				j = j + 2;
				break;
				
			case '\n':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = 'n';
				j = j + 2;
				break;
				
			case '\r':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = 'r';
				j = j + 2;
				break;
				
			case '\t':
				jsonRetBuffer[j] = '\\';
				jsonRetBuffer[j + 1] = 't';
				j = j + 2;
				break;
				
			default:
				jsonRetBuffer[j] = string[i];
				j++;
				break;
		}
		
		if(string[i] == '\0')
		{
			break;
		}
	}
	
	jsonError = JSON_NO_ERROR;
	
	return jsonRetBuffer;
}

char *JSON_WriteBoolean(bool value)
{
	if(value)
	{
		sprintf(jsonRetBuffer, "true");
	}
	
	else
	{
		sprintf(jsonRetBuffer, "false");
	}
	
	jsonError = JSON_NO_ERROR;
	
	return jsonRetBuffer;
}
